from django.urls import include, path, re_path
from django.conf.urls import url

from . import views

urlpatterns = [
    path('', views.PostListView.as_view(), name='users'),
    path('my-posts/', views.MyPostListView.as_view(), name='my-posts'),
    path('create-post/', views.CreatePostView.as_view(), name='create-post'),
    path('by-date/', views.PostListByDate.as_view(), name='post-by-date'),
    re_path(r'^(?P<pk>[0-9]+)/$', views.PostDetailView.as_view(), name='post-detail'),
]