from django.shortcuts import render
from rest_framework import generics
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.exceptions import PermissionDenied
from rest_framework.views import exception_handler

from . import models
from . import serializers

class PostListView(generics.ListCreateAPIView):
    queryset = models.Post.objects.all()
    serializer_class = serializers.PostSerializer
    filter_backends = (DjangoFilterBackend,)
    filter_fields = ('objective', 'description')

class PostDetailView(generics.RetrieveUpdateDestroyAPIView):
	queryset = models.Post.objects.all()
	serializer_class = serializers.PostSerializer
	def get(self, request, pk):
		query = models.Post.objects.get(id=pk)
		if(query.user == request.user or request.user.is_staff):
			serializer = serializers.PostSerializer(query)
			return Response(serializer.data)
		else:
			raise PermissionDenied()

class MyPostListView(generics.ListAPIView):
	serializer_class = serializers.PostSerializer
	queryset = models.Post.objects.all()
	# def get(self, request):
	# 	query = models.Post.objects.filter(user=request.user.id).order_by('-pub_date')
	# 	serializer = serializers.PostSerializer(query, many=True)
	# 	return Response(serializer.data)

class CreatePostView(generics.CreateAPIView):
	serializer_class = serializers.PostSerializer


class PostListByDate(generics.ListAPIView):
	serializer_class = serializers.PostSerializer
	queryset = models.Post.objects.order_by('-pub_date')[:10]
	filter_backends = (DjangoFilterBackend,)
	filter_fields = ('objective', 'description')
	def get(self, request):
		try:
			objects = int(request.GET.get('objects'))
		except Exception as e:
			objects = 0
		query = models.Post.objects.order_by('-pub_date')[objects:(objects+10)]
		serializer = serializers.PostSerializer(query, many=True)
		return Response(serializer.data)


# class SearchPostList(generics.ListAPIView):
# 	serializer_class serializers.PostSerializer
# 	queryset = models.Post.objects.all()
# 	def get(self, request):
# 		try:
# 			objetive = request.GET.get('objetive')
# 		except Exception as e:
# 			fil = ''
# 		try:
# 			desc = request.GET.get
# 		except Exception as e:
# 			raise e
# 		try:
# 			pub_date = request.GET.get('pub_date')
# 		except Exception as e:
# 			pub_date 
# 		query = models.