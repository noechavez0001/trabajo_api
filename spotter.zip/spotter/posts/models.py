from django.db import models
from django.contrib.auth.models import User
from django.conf import settings
from users.models import CustomUser

# Create your models here.
class Post(models.Model):
	user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete='CASCADE', default=1)
	latitude = models.DecimalField(max_digits=9, decimal_places=6, default=40.712784)
	longitude = models.DecimalField(max_digits=9, decimal_places=6, default=-74.005941)
	address = models.CharField(blank=True, max_length=500)
	objective = models.CharField(max_length=250)
	description = models.TextField()
	pub_date = models.DateTimeField(auto_now=False, auto_now_add=True)
	image = models.ImageField(blank=True, null=True)

	def __str__(self):
		return self.objective