from django.shortcuts import render
from rest_framework import generics
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from rest_framework.response import Response

from . import models
from . import serializers

class UserListView(generics.ListCreateAPIView):
    queryset = models.CustomUser.objects.all()
    serializer_class = serializers.UserSerializer
    permission_classes = (IsAdminUser,)

class UserDetailView(generics.RetrieveUpdateDestroyAPIView):
	queryset = models.CustomUser.objects.all()
	serializer_class = serializers.UserSerializer
	permission_classes = (IsAdminUser,)

class CurrentUserView(generics.RetrieveUpdateAPIView):
	serializer_class = serializers.UserSerializer
	def get(self, request):
		serializer = serializers.UserSerializer(request.user)
		return Response(serializer.data)
