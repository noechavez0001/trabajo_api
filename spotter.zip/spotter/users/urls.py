from django.urls import include, path, re_path
from django.conf.urls import url

from . import views

urlpatterns = [
    path('', views.UserListView.as_view(), name='users'),
    re_path(r'^(?P<pk>[0-9]+)/$', views.UserDetailView.as_view(), name='user-detail'),
    path('me/', views.CurrentUserView.as_view(), name='my-user'),
]